//
// Created by imri on 5/22/2019.
//

#ifndef OS_EX4_UTIL_H
#define OS_EX4_UTIL_H

#include <cstdint>
#include <cstdio>
#include <algorithm>
#include "MemoryConstants.h"
#include "PhysicalMemory.h"
#include <cassert>
#include <string>

typedef struct {
    word_t frame;
    uint64_t address;
} PhysicalAddress;

uint64_t translateAddress(uint64_t virtualAddress);

std::string binaryRepresentation(word_t x);

void clearTable(uint64_t frameIndex);

#endif //OS_EX4_UTIL_H
