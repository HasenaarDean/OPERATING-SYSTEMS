//
// Created by imri on 5/22/2019.
//

#include "util.h"

uint64_t getPage(uint64_t address) {
    return address >> OFFSET_WIDTH;
}

void populateChildren(word_t frame, uint64_t *childrenAddress, word_t *childrenContent) {
    for (uint64_t i = 0; i < PAGE_SIZE; i++) {
        childrenAddress[i] = ((uint64_t) frame) * PAGE_SIZE + i;
        PMread(childrenAddress[i], &childrenContent[i]);
    }
}

uint64_t max(uint64_t x, uint64_t y) {
    return x > y ? x : y;
}

uint64_t getOffset(uint64_t address) {
    uint64_t offsetMask = 0;
    for (int i = 0; i < OFFSET_WIDTH; i++) {
        offsetMask += 1LL << i;
    }
    return address & offsetMask;
}

uint64_t getAddress(uint64_t address, uint64_t layer) {
    uint64_t res = address >> (TABLES_DEPTH - layer) * OFFSET_WIDTH;
    return getOffset(res);
}


word_t unusedFrameHelper(word_t frame, word_t maxFrame, uint64_t layer) {
    if (layer == TABLES_DEPTH || maxFrame == NUM_FRAMES) {
        return maxFrame;
    } else {
        uint64_t childrenAddress[PAGE_SIZE];
        word_t childrenContent[PAGE_SIZE];
        populateChildren(frame, childrenAddress, childrenContent);
        for (word_t i = 0; i < PAGE_SIZE; i++) {
            if (childrenContent[i] != 0) {
                childrenContent[i] = unusedFrameHelper(childrenContent[i],
                                                       max(childrenContent[i], maxFrame), layer + 1);
            } else {
                childrenContent[i] = maxFrame;
            }
        }
        word_t *max_child = std::max_element(childrenContent, childrenContent + PAGE_SIZE);
        return *max_child;
    }
}

word_t unusedFrame() {
    word_t result = unusedFrameHelper(0, 0, 0) + 1;
    return result == NUM_FRAMES ? 0 : result;
}

uint64_t distance(uint64_t x, uint64_t y) {
    return x > y ? x - y : y - x;
}

uint64_t min(uint64_t x, uint64_t y) {
    return x < y ? x : y;
}

typedef struct {
    word_t frame;
    uint64_t distance;
} CyclicDistanceData;

CyclicDistanceData
cyclicDistance(word_t frame, uint64_t layer, uint64_t currentPage, uint64_t targetPage) {
    if (layer == TABLES_DEPTH) {
        uint64_t distanceFromCurrentToTarget = distance(targetPage, currentPage);
        return CyclicDistanceData{
                frame,
                min(NUM_PAGES - distanceFromCurrentToTarget, distanceFromCurrentToTarget)
        };
    } else {
        word_t children[PAGE_SIZE];
        uint64_t childrenValues[PAGE_SIZE];
        word_t frames[PAGE_SIZE];
        for (uint64_t i = 0; i < PAGE_SIZE; i++) {
            uint64_t nextAddress = ((uint64_t) frame) * PAGE_SIZE + i;
            PMread(nextAddress, &children[i]);
        }
        for (word_t i = 0; i < PAGE_SIZE; i++) {
            if (children[i] != 0) {
                uint64_t childPage = ((uint64_t) frame) * PAGE_SIZE + i;
                CyclicDistanceData res = cyclicDistance(children[i], layer + 1, childPage, targetPage);
                childrenValues[i] = res.distance;
                frames[i] = res.frame;
            } else {
                childrenValues[i] = 0;
                frames[i] = children[i];
            }
        }
        uint64_t *max_child = std::max_element(childrenValues, childrenValues + PAGE_SIZE);
        return CyclicDistanceData{frames[max_child - childrenValues], *max_child};
    }
}

void evictPage(word_t root, word_t layer, word_t toEvict, uint64_t virtualPage) {
    if (layer == TABLES_DEPTH) return;
    word_t children[PAGE_SIZE];
    uint64_t childrenPages[PAGE_SIZE];
    uint64_t childrenAddress[PAGE_SIZE];
    for (uint64_t i = 0; i < PAGE_SIZE; i++) {
        childrenAddress[i] = ((uint64_t) root) * PAGE_SIZE + i;
        childrenPages[i] = (virtualPage << OFFSET_WIDTH) + i;
        PMread(childrenAddress[i], &children[i]);
    }
    for (uint64_t i = 0; i < PAGE_SIZE; i++) {
        if (toEvict && children[i] == toEvict) {
            assert(layer == TABLES_DEPTH - 1);
//            std::cout << "evicting page: " << childrenPages[i] << std::endl;
            PMevict(toEvict, childrenPages[i]);
            PMwrite(childrenAddress[i], 0);
            return;
        } else if (children[i] != 0) {
            evictPage(children[i], layer + 1, toEvict, childrenPages[i]);
        }
    }
}

word_t evictedFrame(uint64_t targetPage) {
//    printf("evicting for page %lu\n", targetPage);
    CyclicDistanceData results = cyclicDistance(0, 0, 0, targetPage);
    evictPage(0, 0, results.frame, 0);
    return results.frame;
}

word_t emptyTableHelper(word_t root, word_t layer, uint64_t address, word_t currentFrame) {
    if (layer == TABLES_DEPTH) {
        return false;
    }

    word_t children[PAGE_SIZE];
    uint64_t childrenAddress[PAGE_SIZE];
    populateChildren(root, childrenAddress, children);

    bool emptyTable = true;
    for (word_t i = 0; i < PAGE_SIZE; i++) {
        if (children[i] != 0) {
            emptyTable = false;
            auto child = emptyTableHelper(children[i], layer + 1, childrenAddress[i], currentFrame);
            if (child) return child;
        }
    }

    if (emptyTable && root != currentFrame && root != 0) {
        PMwrite(address, 0);
        return root;
    } else {
        return 0;
    }
}

word_t emptyTable(word_t currentFrame) {
    return emptyTableHelper(0, 0, 0, currentFrame);
}

word_t findFrame(uint64_t targetPage, word_t currentFrame) {
    word_t nextFrame = 0;
    if (!nextFrame) nextFrame = emptyTable(currentFrame);
    if (!nextFrame) nextFrame = unusedFrame();
    if (!nextFrame) nextFrame = evictedFrame(targetPage);
    assert(nextFrame != 0);
    assert(nextFrame < NUM_FRAMES);
//    printf("received frame %d\n", nextFrame);
    return nextFrame;
}

std::string binaryRepresentation(word_t x) {
    std::string result;
    while (x != 0) {
        result = (x % 2 == 0 ? "0" : "1") + result;
        x /= 2;
    }
    return result;
}

uint64_t combine(word_t frameIndex, word_t offset) {
    std::string index = binaryRepresentation(offset);
    index.insert(index.begin(), OFFSET_WIDTH - index.length(), '0');
    std::string binary = binaryRepresentation(frameIndex) + index;
    return stoull(binary, nullptr, 2);
}

uint64_t translateAddress(uint64_t virtualAddress) {
    uint64_t tableIndex = 0;
    uint64_t currentLayer = 0;
    word_t nextFrame = 0;
    uint64_t virtualPage = getPage(virtualAddress);
    while (currentLayer < TABLES_DEPTH) {
        tableIndex = getAddress(virtualAddress, currentLayer);
        uint64_t nextAddress = nextFrame * PAGE_SIZE + tableIndex;
        word_t currentFrame = nextFrame;
        PMread(nextAddress, &nextFrame);
        if (nextFrame == 0) {
//            printf("tableIndex[%lu, %lu] is 0, need to populate\n", currentLayer, tableIndex);
            nextFrame = findFrame(nextAddress, currentFrame);
            PMwrite(nextAddress, nextFrame);
            clearTable(nextFrame);
            if (currentLayer + 1 == TABLES_DEPTH) {
//                std::cout << "restoring page: " << virtualPage << std::endl;;
                PMrestore(nextFrame, virtualPage);
            }
        }
        currentLayer++;
    }
    uint64_t offset = getOffset(virtualAddress);
    return combine(nextFrame, offset);
}

void clearTable(uint64_t frameIndex) {
    for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
        PMwrite(frameIndex * PAGE_SIZE + i, 0);
    }
}